var config = {
    map: {
        '*': {
            mousewheel:           'Magento_Theme/js/jquery.mousewheel',
        }
    }
};